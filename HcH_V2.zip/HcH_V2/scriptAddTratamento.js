
// Cria um objeto para armazenar os dados do tratamento
var tratamentoData = {
  nomeTratamento: document.getElementById('nomeTratamento').value,
  medicamento: document.getElementById('medicamento').value,

  procedimentos: document.getElementById('procedimentos').value,
  dataFinal: document.getElementById('dataFinal').value
};

// Envia os dados do tratamento para a API
fetch('http://127.0.0.1:8080/tratamento', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(tratamentoData)
})
.then(resposta => resposta.json())
.then(dados => {
  console.log('Dados do tratamento enviados com sucesso:', dados);
})
.catch(erro => console.error('Erro:', erro));
